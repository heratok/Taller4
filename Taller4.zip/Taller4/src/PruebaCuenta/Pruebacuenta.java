
package PruebaCuenta;

import java.util.Scanner;
import punto2.*;
public class Pruebacuenta {
    public static void main(String[] args) {
        int noCuenta;
        String nombreCliente;
        double saldo;
        Scanner leer=new Scanner(System.in);
        cuenta cuenta=new cuenta();
        System.out.println("INGRESE EL NUMERO DE CUENTA: ");
        noCuenta=leer.nextInt();
        System.out.println("INGRESE EL NOMBRE DEL CLIENTE: ");
        nombreCliente=leer.next();
        System.out.println("INGRESE EL SALDO DEL CLIENTE: ");
        saldo=leer.nextDouble();
        
        System.out.println("ESCOJA UNA OPCION: ");
        System.out.println("1.consignar");
        System.out.println("2.restirar");
        int opciones=leer.nextInt();
        boolean consignar=false;
        boolean retirar=false;
        while (consignar==false && retirar==false){
            if (opciones==1){
                consignar(cuenta);
                break;
            }
            else if (opciones==2){
                retirar(cuenta);
                break;
            }
        }
        


    }
    
    public static void consignar(cuenta cuenta){
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese la cantidad a consignar : ");
        double consignar=leer.nextDouble();
        cuenta.setsaldo(cuenta.getsaldo()+consignar);
        System.out.printf("su saldo es: %.2f \n",cuenta.getsaldo());    
    }
    public static void retirar(cuenta cuenta){
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese la cantidad a retirar");
        double retirar=leer.nextDouble();
        cuenta.setsaldo(cuenta.getsaldo()-retirar);
        System.out.printf("su saldo es: %.2f \n",cuenta.getsaldo());
        
    }
    
}
