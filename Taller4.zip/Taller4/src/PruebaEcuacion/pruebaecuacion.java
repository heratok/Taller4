package PruebaEcuacion;

import punto6.Ecuacion;

public class pruebaecuacion {
    public static void main(String[] args) {
        System.out.println(new Ecuacion(4, 4, 6, 7).elString());
    }  
}