
package PruebaHabitacion;

import punto4.*;
import java.util.Scanner;

public class PruebaHabitacion {
    public static void main(String[] args) {
        double ancho;double largo;double altura;
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese el ancho: ");ancho=leer.nextDouble();
        System.out.println("Ingrese el largo: ");largo=leer.nextDouble();
        System.out.println("Ingrese la altura: ");altura=leer.nextDouble();
        
        
        Habitacion r = new Habitacion();
        r.setaltura(altura);
        r.setancho(ancho);
        r.setlargo(largo);
        imprimircalculo(r);
        
        
        
    }
    public static void imprimircalculo(Habitacion r){
        System.out.println("Los metros cuadrados requeridos para el enchape de su piso son :"+r.calcularenchapepiso());
        System.out.println("Los metros cuadrados requeridos para el tapizado de sus paredes es : "+r.calculartapizarparedes());
    }
    
}
