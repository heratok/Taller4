
package PruebaLibro;
import punto7.*;
import java.util.Scanner;
public class pruebalibro {
    public static void main(String[] args) {
        String titulo,primerNombre,segundoNombre,primerApellido,ISBN,edicion,ciudad = null,pais,fechaedicion,editorial;
        int paginas;
        Scanner leer=new Scanner(System.in);
        libro libros=new libro();
        for (int i = 0; i < 2; i++) {
            System.out.println("Libro"+(i+1)+": ");
            System.out.println("ingrese el titulo del libro: ");
            titulo=leer.nextLine();
            System.out.println("ingrese el primer nombre: ");
            primerNombre=leer.nextLine();
            System.out.println("ingrese el segundo nombre: ");
            segundoNombre=leer.nextLine();
            System.out.println("ingrese el primer apellido: ");
            primerApellido=leer.nextLine();
            System.out.println("ingrese el ISBN: ");
            ISBN=leer.nextLine();
            System.out.println("ingrese el numero de paginas: ");
            paginas=leer.nextInt();
            System.out.println("ingrese la edicion: ");
            edicion=leer.next();
            System.out.println("ingrese la ciudad: ");
            edicion=leer.next();
            System.out.println("ingrese el pais: ");
            pais=leer.next();
            System.out.println("ingrese la fecha de edicion: ");
            fechaedicion=leer.next();
            System.out.println("ingrese el editorial: ");
            editorial=leer.nextLine();
            libros.settitulo(titulo);
            libros.setprimerNombre(primerNombre);
            libros.setsegundoNombre(segundoNombre);
            libros.setprimerApellido(primerApellido);
            libros.setISBN(ISBN);
            libros.setpaginas(paginas);
            libros.setedicion(edicion);
            libros.setciudad(ciudad);
            libros.setpais(pais);
            libros.setfechaedicion(fechaedicion);
            libros.seteditorial(editorial);
            imprimir(libros);
   
        }
    }
    public static void imprimir(libro libros){
        System.out.println("Titulo del libro: "+libros.gettitulo() );
        System.out.println(""+libros.getedicion()+" edicion");
        System.out.println("El Autor: "+libros.getprimerNombre()+" "+libros.getsegundoNombre()+" "+libros.getprimerApellido());
        System.out.println("ISBN: "+libros.getISBN());
        System.out.println(libro.Editorial+"");
        System.out.println("ciudad: "+libros.getciudad()+" "+"("+libros.getpais()+")"+" "+libros.getfechaedicion());
        System.out.println(libros.getpaginas()+" paginas");
        
        
    }
    
}
