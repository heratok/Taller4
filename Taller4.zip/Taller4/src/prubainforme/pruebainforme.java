
package prubainforme;

import punto3.*;

public class pruebainforme {
    public static void main(String[] args) {
        informe Infrome=new informe();
        Infrome.ingresardatos();
        imprimir(Infrome);
  
        
        
    }
    
    public static void imprimir(informe informe){
        System.out.printf("el promedio es: %.2f\n",informe.promventasaño());
        System.out.println("el acumulado de ventas es: "+informe.acumuladoventasaño());
        System.out.println("el mes con mas ventas fue el: "+informe.mesmaxventas());
        System.out.println("el mes con menos ventas fue el: "+informe.mesminventas());
    }  
}

