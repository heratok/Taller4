
package pruebaTrianguloIsoceles;

import java.util.Scanner;
import punto5.triangulosIsoceles;


public class pruebaTriangulo {

    public static void main(String[] args) {
        Scanner leer = new Scanner (System.in);
        triangulosIsoceles triangulo = new triangulosIsoceles ();
        
        triangulo.registrarDato();
        System.out.printf(" \nel area es:[ %.1f ]", triangulo.calcularArea());
        System.out.printf(" \nlos lados son:[%.1f ] ", triangulo.longitudLados());
        System.out.printf(" \nel perimetro es:[%.1f] ", triangulo.perimetro());
        System.out.printf(" \nel angulo vertice  es:[%.1f] ", triangulo.anguloVertice ( ) );
 
    }
    
}
