
package pruebacoche;

import punto1.*;
import java.util.Scanner;

public class pruebacoche {
    public static void main(String[] args) {
        String color;
        String marca;
        String modelo;
        int numcaballos;
        int numpuertas;
        String matricula;
        
        for (int i = 0; i <3; i++) {
        Scanner leer=new Scanner(System.in);
        System.out.println("ingrese el color del coche: ");
        color=leer.nextLine();
        System.out.println("ingrese la marca del coche: ");
        marca=leer.nextLine();
        System.out.println("ingrese el modelo del coche: ");
        modelo=leer.nextLine();
        System.out.println("ingrese la cantidad de caballos de fuerza que tines el coche: ");
        numcaballos=leer.nextInt();
        System.out.println("ingrese el numero de puertas que tiene el coche: ");
        numpuertas=leer.nextInt();
        System.out.println("ingrese la matricula del coche: ");
        matricula=leer.next();
        System.out.println("---------------------------------------------------------------------");
        
        coche estilo=new coche();
        estilo.setcolor(color);
        estilo.setmarca(marca);
        estilo.setmodelo(modelo);
        estilo.setnumcaballos(numcaballos);
        estilo.setnumpuertas(numpuertas);
        estilo.setmatricula(matricula);
        imprimirCoche(estilo);
        System.out.println("-------------------------------------------------------------------------");
            
        }
    }
 
    public static void imprimirCoche(coche estilo){
        System.out.println("El color del coche es: "+estilo.getcolor());
        System.out.println("La marca del coche es: "+estilo.getmarca());
        System.out.println("El modelo del coche es: "+estilo.getmodelo());
        System.out.println("El coche tine "+estilo.getnumcaballos()+" caballos de fuerza");
        System.out.println("El coche tine "+estilo.getnumpuertas()+" puertas");
        System.out.println("La matricula del coche es: "+estilo.getmatricula());

    }
}
