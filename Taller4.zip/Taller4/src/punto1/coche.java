
package punto1;

public class coche {
    private String color;
    private String marca;
    private String modelo;
    private int numcaballos;
    private int numpuertas;
    private String matricula;
    
    public coche(){
        color="";
        marca="";
        modelo="";
        numcaballos=0;
        numpuertas=0;
        matricula="";
    }
    //usar metodo get
    public String getcolor(){
        return this.color;
    }
    
    public String getmarca(){
        return this.marca;
    }
    
    public String getmodelo(){
        return this.modelo;
    }
    
    public int getnumcaballos(){
        return this.numcaballos;
    }
    
    public int getnumpuertas(){
        return this.numpuertas;
    }
    public String getmatricula(){
        return this.matricula;
    }
    
    //usar metodo set
    
    public void setcolor(String  color){
        this.color = color;
    }
    public void setmarca(String marca){
        this.marca = marca;
    }
    public void setmodelo(String modelo){
        this.modelo = modelo;
    }
    public void setnumcaballos(int numcaballos){
        this.numcaballos = numcaballos;
    }
    public void setnumpuertas(int numpuertas){
        this.numpuertas = numpuertas;
    }
    public void setmatricula(String matricula){
        this.matricula = matricula;
    }
    
}
