
package punto2;


public class cuenta {
    private int noCuenta;
    private String nombreCliente;
    private double saldo;
    
    
    public cuenta(){
        noCuenta=0;
        nombreCliente="";
        saldo=0;
    }
    public int getnoCuenta(){
        return this.noCuenta;
    }
    public String getnombreCliente(){
        return this.nombreCliente;
    }
    public double getsaldo(){
       return  this.saldo;
    }
    
    public void setnoCuenta(int nocuenta){
        this.noCuenta= nocuenta;
    }
     public void setnombreCliente(String name){
         this.nombreCliente= name;
     }
    public void setsaldo(double saldo){
        this.saldo= saldo;
    }
    
}

