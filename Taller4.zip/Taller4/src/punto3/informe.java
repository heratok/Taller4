
package punto3;

import java.util.Scanner;

public class informe {
    double limit;
    private double [] reporteVenta=new double[12];
    double suma;
    
    public informe(){
        this.limit=12;
    }
    public double[] getreporteVenta(){
        return this.reporteVenta;
    }
    public double getsuma(){
        return this.suma;
    }
    public void setreporteVenta(double [] reporteVenta){
        this.reporteVenta = reporteVenta;
    }
    public void setsuma(double suma ){
        this.suma = suma;
    }
    
    
    public void ingresardatos(){
        Scanner leer=new Scanner(System.in);
        for (int i = 0; i < limit; i++) {
            System.out.println("Ingrese el reporte de venta del mes "+(i+1)+": ");
            reporteVenta[i]=leer.nextDouble();
            
        }
    }
    

    public double promventasaño(){
        double prom; 
        for (int i = 0; i < reporteVenta.length; i++) 
            suma += reporteVenta[i];
            prom=this.suma/this.limit;    
        return prom; 
    }
    public double acumuladoventasaño(){
        return  suma;
    }
    double mayor,menor;
    int pos=-1;
    public double mesmaxventas(){
        for (int i = 0; i < reporteVenta.length; i++) 
            if  (reporteVenta[i]>mayor){
                mayor=reporteVenta[i];
                pos=i;           
        }
        return (pos+1);  
    }
    int pos2=0;
    public double mesminventas(){
        for (int i = 0; i < reporteVenta.length; i++) {
            if (reporteVenta[i]<menor){
                menor=reporteVenta[i];
                pos2=i;      
            }   
        }
        return (pos2+1);
    }
}
