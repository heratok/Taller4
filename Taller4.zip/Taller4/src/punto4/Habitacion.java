
package punto4;


public class Habitacion {
    private double largo;
    private double ancho;
    private double altura;
    
    public Habitacion(){
        largo=0;
        ancho=0;
        altura=0;
    }
    
    public double getlargo(){
        return this.largo;
    }
    public double getancho(){
        return this.ancho;
    }
    public double getaltura(){
        return  this.altura;
    }
    public void setlargo(double  largo){
        this.largo = largo;
    }
    public void setancho(double ancho){
        this.ancho = ancho;
    }
    public void setaltura(double altura){
        this.altura = altura;
    }
    public double calcularenchapepiso(){
        double calcularenchapepiso=this.largo * this.ancho;
        return calcularenchapepiso;
    }
    public double calculartapizarparedes(){
        double calculartapizado=this.altura * this.ancho;
        return calculartapizado;
        
    }
    

}
