
package punto5;

import java.util.Scanner;
public class triangulosIsoceles{
    double base;
    double altura;
    // metodo constructor
    public triangulosIsoceles (){
    
    }
    // metodo get
    public double getBase (){ return base;}
    public double getAltura (){ return altura;}
    // metodo Set
    public void  setBase (double base){ this.base = base ;}
    public void setAltura (double altura ) { this.altura = altura;}
    // metodos 
    
    public void registrarDato (){
        Scanner leer = new Scanner (System.in);
        System.out.print(" Digite Base ");
        base=leer.nextDouble();
        System.out.print(" Digite Altura ");
        altura = leer.nextDouble();
        System.out.println("\n_________________");
        
        
    }
    
    public double calcularArea (){
        return (this.base*this.altura)/2;
    }
    public double longitudLados(){
        double aux= this.base/2;
        double h = (altura*altura)+(aux*aux);
        double lados = Math.sqrt(h); // raiz cuadrada
        return  lados; 
    }
    public double perimetro ( ){
        return (2*this.longitudLados()+base);
    }
    public double anguloVertice ( ){
    double valor ;
    double angulo ;
    angulo =  altura/this.longitudLados();
     valor = Math.acos(angulo);
    double aux = Math.toDegrees(valor);
    return aux*2;
    }
    
}
