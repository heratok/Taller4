
package punto7;

public class libro {
    private String titulo;
    private String primerNombre;
    private String segundoNombre;
    private String primerApellido;
    private int ISBN;
    private int paginas;
    private String edicion;
    private String ciudad;
    private String pais;
    private String fechaedicion;
    private String editorial;
    
    public static String Editorial="Prentice-Hall";

    
    public libro(){
    }
    //metodo getter
    public String gettitulo(){
        return this.titulo;
    }
    public String getprimerNombre(){
        return this.primerNombre;
    }
    public String getsegundoNombre(){
        return this.segundoNombre;
    }
    public String getprimerApellido(){
        return this.primerApellido;
    }
    public int getISBN(){
        return this.ISBN;
    }
    public int getpaginas(){
        return this.paginas;
    }
    public String getedicion(){
        return this.edicion;
    }
    public String getciudad(){
        return this.ciudad;
    }
    public String getpais(){
        return this.pais;
    }
    public String getfechaedicion(){
        return this.fechaedicion;
    }
    public String geteditorial(){
        return this. editorial;
    }
    //metodo setter
    public void settitulo(String titulo){
        this.titulo = titulo;
    }
    public void setprimerNombre(String primernombre){
        this.primerApellido = primernombre;
    }
    public void setsegundoNombre(String segundonombre){
        this.segundoNombre =segundonombre;
    }
    public void setprimerApellido(String primerapellido){
        this.primerApellido = primerapellido;
    }
    public void setISBN(int isbn){
        this.ISBN = isbn;
    }
    public void setpaginas(int paginas){
        this.paginas=paginas;
    }
    public void setedicion(String edicion){
        this.edicion =edicion;
    }
    public void setciudad(String ciudad){
        this.ciudad = ciudad;
    }
    public void setpais(String pais){
        this.pais=pais;
    }
    public void setfechaedicion(String fechaedicion){
        this.fechaedicion=fechaedicion;
    }
    public void seteditorial(String editorial){
        this.editorial=editorial;
    }

    public void setISBN(String ISBN) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
}
